package org.usfirst.frc.team702.robot;

import edu.wpi.first.wpilibj.Joystick;

public class BagelController extends Joystick {

	public BagelController(int port) {
		super(port);
		// TODO Auto-generated constructor stub
	}

}
